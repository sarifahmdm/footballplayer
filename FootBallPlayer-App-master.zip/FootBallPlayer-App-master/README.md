Video Tutorial:
https://medium.com/@asep/latihan-ambil-data-dari-json-format-dan-menampilkannya-di-listview-android-60c1582aa104
 footballplayer
